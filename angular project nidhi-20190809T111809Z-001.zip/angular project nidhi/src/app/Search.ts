// this is the data structure for the Seach class (body type)

export class Search{
	SearchElement: string;
	val: Array<Object>;
	SearchTime: string;
}
