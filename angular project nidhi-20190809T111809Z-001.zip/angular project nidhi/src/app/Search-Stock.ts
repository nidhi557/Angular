import { Search } from './search';
export const SEARCH : Search[] = [
	{SearchElement:'Tomato', val:[20,22,30,23],SearchTime:''},
	{SearchElement:'Cucumber',val:[30,35,40,42],SearchTime:''},
	{SearchElement:'Bringal',val:[25,22,24,20],SearchTime:''},
	{SearchElement:'Green Peas',val:[28,26,30,45],SearchTime:''},
	{SearchElement:'Onion',val:[10,13,12,10],SearchTime:''}
];
